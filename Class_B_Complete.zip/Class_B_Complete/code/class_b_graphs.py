
import base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def restore_graphs(data, output, report):
    plt.rcParams.update({'font.size':11})
    labels={'x_twitter':'X','youtube_handle':'YouTube'}
    fig, ax=plt.subplots(figsize=(9,4.5))
    lengths=data.handle.str.len()
    bins=np.arange(0,lengths.max()+2)-.5
    for platform,group in data.groupby('platform'):
        ax.hist(group.handle.str.len(),bins=bins,density=True,histtype='step',linewidth=2,label=labels[platform])
    ax.set(xlabel='Handle length (Unicode code points)',ylabel='Proportion per character',title='Class B: handle length by platform')
    ax.legend();fig.tight_layout();fig.savefig(output/'length_distribution.png',dpi=160);plt.close(fig)
    age=pd.read_csv(output/'by_platform_age.csv')
    age=age[age.feature=='length']
    bands=['Under 18','18–29','30–39','40–49','50–59','60–69','70–100']
    fig,ax=plt.subplots(figsize=(9,4.5))
    for platform,group in age.groupby('platform'):
        q=group.set_index('age_band').reindex(bands)
        errors=np.stack([q['mean']-q.ci_low,q.ci_high-q['mean']])
        ax.errorbar(bands,q['mean'],yerr=errors,marker='o',capsize=3,label=labels[platform])
    ax.set(xlabel='Recorded age band',ylabel='Mean handle length (characters)',title='Class B: age patterns within each platform')
    ax.legend(title='Bars show 95% confidence intervals');fig.tight_layout();fig.savefig(output/'age_lengths.png',dpi=160);plt.close(fig)
    section='<section id="restored-graphs"><h2>Platform and age visualizations</h2>'
    for name,alt in [('length_distribution.png','Handle length distributions by platform'),('age_lengths.png','Mean handle length by age band and platform')]:
        encoded=base64.b64encode((output/name).read_bytes()).decode()
        section+=f'<img style="width:100%;max-width:1000px" src="data:image/png;base64,{encoded}" alt="{alt}">'
    section+='<p>The age graph uses every record with an age in the displayed band, without additional demographic filters. Bars are record-level 95% confidence intervals around the mean, not standard deviations or ranges of individual usernames. Missing ages and recorded ages over 100 are excluded from this graph. Repeated-person dependence is addressed separately in the cluster-robust models. Not all rows and associated metadata could be independently verified.</p></section>'
    return report.replace('<h2>Platform descriptions</h2>',section+'<h2>Platform descriptions</h2>')
