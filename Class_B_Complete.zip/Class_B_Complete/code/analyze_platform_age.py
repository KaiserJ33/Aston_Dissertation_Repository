


import argparse, base64, html, json, re, runpy, shutil, sys, unicodedata, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
parser=argparse.ArgumentParser();parser.add_argument('input',nargs='?',default='upload/Class_B_X_YouTube_Final(1).csv');parser.add_argument('--output',default='Class_B_Platform_Age');args=parser.parse_args()
sys.argv=['platform_age_core.py',args.input,'--output',args.output]
b=runpy.run_path(str(Path(__file__).with_name('platform_age_core.py')))
d=b['d'];out=b['out'];summary=b['summary'];holm=b['holm'];binary=b['binary'];continuous=b['continuous'];htmltable=b['htmltable'];new={}
def save(name,df):new[name]=df;df.to_csv(out/(name+'.csv'),index=False)
def normalize(x):return ''.join(c for c in unicodedata.normalize('NFKC',str(x)).casefold() if c.isalnum())
def labeltokens(x):return [normalize(t) for t in re.findall(r'[^\W_]+',str(x),flags=re.UNICODE) if len(normalize(t))>=3]
nameknown=d.itemLabel.ne('');d['label_length']=d.itemLabel.str.len();d['label_token_count']=d.itemLabel.map(lambda x:len(re.findall(r'[^\W_]+',x)))
hn=d.handle.map(normalize);ln=d.itemLabel.map(normalize);tokens=d.itemLabel.map(labeltokens)
d['normalized_label_equals_handle']=[int(bool(n) and n==h) for n,h in zip(ln,hn)]
d['normalized_label_in_handle']=[int(bool(n) and n in h) for n,h in zip(ln,hn)]
d['label_token_in_handle']=[int(any(t in h for t in ts)) for ts,h in zip(tokens,hn)]
d['label_non_ascii']=d.itemLabel.map(lambda x:int(any(ord(c)>127 for c in x)))
original_binary=list(binary);original_continuous=list(continuous)
binary.extend(['normalized_label_equals_handle','normalized_label_in_handle','label_token_in_handle','label_non_ascii']);continuous.extend(['label_length','label_token_count'])

save('name_relationships_by_platform',summary(d[nameknown],['platform']))
save('name_relationships_by_platform_age',summary(d[nameknown],['platform','age_band']))
binary[:]=original_binary;continuous[:]=original_continuous
metadata=['occupations','citizenships','languages'];memberships={};coverage=[]
for field in metadata:
 lists=d[field].map(lambda x:sorted(set(t.strip() for t in x.split('|') if t.strip())))
 memberships[field]=lists
 d[field+'_membership_count']=lists.map(len)
 known=lists.map(bool)
 e=d.assign(category=lists).explode('category');e=e[e.category.notna()]
 save(field+'_all_categories',summary(e,['category']))
 save(field+'_by_platform',summary(e,['platform','category']))
 save(field+'_exact_combinations',summary(d.assign(metadata_value=d[field].replace('','Missing')),['platform','metadata_value']))
 save(field+'_missingness',summary(d.assign(metadata_status=np.where(known,'Recorded','Missing')),['platform','metadata_status']))
 save(field+'_membership_counts',summary(d.assign(membership_count=d[field+'_membership_count']),['platform','membership_count']))
 counts=e.groupby('category').agg(n=('handle','size'),unique_people=('qid','nunique')).reset_index().sort_values('n',ascending=False)
 save(field+'_category_counts',counts)
 for p,g in d.groupby('platform'):
  coverage.append(dict(field=field,platform=p,n=len(g),known=int(g[field].ne('').sum()),missing=int(g[field].eq('').sum()),multiple=int((g[field+'_membership_count']>1).sum())))
save('all_metadata_coverage',pd.DataFrame(coverage))

def parse_birth(x):
 if not x:return ('Missing',np.nan)
 if re.fullmatch(r'\d{4}',x):return ('Year only',int(x))
 if re.fullmatch(r'\d{4}-\d{2}',x):
  try:pd.Timestamp(x+'-01');return ('Month precision',int(x[:4]))
  except Exception:return ('Invalid date',np.nan)
 if re.fullmatch(r'\d{4}-\d{2}-\d{2}',x):
  try:pd.Timestamp(x);return ('Day precision',int(x[:4]))
  except Exception:return ('Invalid date',np.nan)
 return ('Other/unparsed',np.nan)
parsed=d.date_of_birth.map(parse_birth);d['birth_date_precision']=parsed.map(lambda x:x[0]);d['birth_year']=parsed.map(lambda x:x[1]);d['birth_decade']=d.birth_year.map(lambda x:'Missing/unparsed' if pd.isna(x) else str(int(x//10)*10)+'s')
save('birth_date_precision',summary(d,['platform','birth_date_precision']))
save('birth_decades',summary(d,['platform','birth_decade']))
save('birth_year_summary',d.groupby('platform').birth_year.agg(['count','mean','std','median','min','max']).reset_index())
save('age_birth_coverage',pd.crosstab([d.platform,d.birth_date_precision],d.age.notna().map({True:'Age recorded',False:'Age missing'})).reset_index())

audit=[]
for p,g in d.groupby('platform'):
 expected='P2002' if p=='x_twitter' else 'P11245'
 audit.append(dict(platform=p,n=len(g),unique_qids=g.qid.nunique(),unique_handles=g.handle.nunique(),valid_qid_format=int(g.qid.str.fullmatch(r'Q\d+').sum()),item_matches_qid=int((g.item.str.rsplit('/',n=1).str[-1]==g.qid).sum()),property_values=' | '.join(sorted(g.property_id.unique())),expected_property=expected,expected_property_matches=int((g.property_id==expected).sum()),repeated_person_platform=int(g.duplicated(['qid','platform']).sum())))
save('identifier_audit',pd.DataFrame(audit))
consistency=[]
for f in ['date_of_birth','age','itemLabel','citizenships','languages','occupations']:
 v=d[d[f].notna()&d[f].astype(str).ne('')].groupby('qid')[f].nunique();consistency.append(dict(field=f,qids_with_multiple_nonmissing_values=int((v>1).sum())))
save('within_person_metadata_consistency',pd.DataFrame(consistency))


tests=[];adjusted=[];outcomes=['length','contains_digit','ends_digit','underscore','lowercase','mixed_case','non_ascii']
for field in metadata:
 known=d[field].ne('');counts=new[field+'_category_counts'];cats=counts[counts.n>=100].head(15).category.tolist()
 for cat in cats:
  membership=memberships[field].map(lambda ls:cat in ls)
  for p,g in [('All',d[known])]+list(d[known].groupby('platform')):
   flag=membership.loc[g.index];u=g[flag];v=g[~flag]
   if min(len(u),len(v))<30:continue
   for f in outcomes:
    a=u[f].to_numpy();c=v[f].to_numpy();pooled=np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(c)-1)*c.var(ddof=1))/(len(a)+len(c)-2))
    if f=='length':test=stats.ttest_ind(a,c,equal_var=False);effect=(a.mean()-c.mean())/pooled if pooled else 0;method='Welch t';ef='Cohen d'
    else:test=stats.fisher_exact([[a.sum(),len(a)-a.sum()],[c.sum(),len(c)-c.sum()]]);effect=2*(np.arcsin(np.sqrt(a.mean()))-np.arcsin(np.sqrt(c.mean())));method='Fisher exact';ef='Cohen h'
    tests.append(dict(field=field,category=cat,platform=p,feature=f,n_member=len(a),n_other_known=len(c),member_mean=a.mean(),other_mean=c.mean(),difference=a.mean()-c.mean(),effect=effect,effect_type=ef,test=method,p=test.pvalue))
  m=d[known&d.age.between(0,100)].copy();flag=membership.loc[m.index].astype(float)
  if min(flag.sum(),len(flag)-flag.sum())<30:continue
  predictors=[np.ones(len(m)),(m.age-40)/10]
  if m.platform.nunique()>1:predictors.append((m.platform=='youtube_handle').astype(float))
  predictors.append(flag);X=np.column_stack(predictors);k=X.shape[1];j=k-1;cl=pd.factorize(m.qid)[0];ng=len(np.unique(cl))
  if np.linalg.matrix_rank(X)<X.shape[1]:continue
  iv=np.linalg.inv(X.T@X)
  for f in outcomes:
   y=m[f].to_numpy(float);coef=iv@X.T@y;res=y-X@coef;scores=np.zeros((ng,k));np.add.at(scores,cl,X*res[:,None]);cov=ng/(ng-1)*(len(m)-1)/(len(m)-k)*iv@(scores.T@scores)@iv;se=np.sqrt(max(cov[j,j],0));crit=stats.t.ppf(.975,ng-1);pv=2*stats.t.sf(abs(coef[j]/se),ng-1) if se>0 else np.nan
   assert np.allclose(coef,np.linalg.lstsq(X,y,rcond=None)[0],atol=1e-8)
   adjusted.append(dict(field=field,category=cat,feature=f,n=len(m),n_member=int(flag.sum()),clusters=ng,platforms=' | '.join(sorted(m.platform.unique())),coefficient=coef[j],se=se,ci_low=coef[j]-crit*se,ci_high=coef[j]+crit*se,p=pv))
t=pd.DataFrame(tests);t['p_holm_field']=t.groupby('field').p.transform(lambda p:holm(p));save('metadata_category_tests',t)
a=pd.DataFrame(adjusted);a['p_holm_field']=a.groupby('field').p.transform(lambda p:pd.Series(holm(p.dropna()),index=p.dropna().index).reindex(p.index));save('metadata_adjusted_models',a)
def displaysummary(field):
 cats=new[field+'_category_counts'].head(15).category.tolist();q=new[field+'_by_platform'];q=q[(q.feature=='length')&q.category.isin(cats)].copy();return q[['platform','category','n','unique_people','mean','sd','ci_low','ci_high']].sort_values(['category','platform'])
name=new['name_relationships_by_platform'];name=name[name.feature.isin(['normalized_label_equals_handle','normalized_label_in_handle','label_token_in_handle'])][['platform','feature','n','percent','sd','ci_low','ci_high']]
disclaimer='Not all rows, account links, public-figure classifications, or associated demographic and biographical metadata could be independently verified. Results describe the supplied Wikidata-linked records and should be interpreted as exploratory associations within this dataset, rather than verified facts about every account holder or representative estimates for entire populations.'
sections=f'''<h2>Verification disclaimer</h2><p class="note"><strong>{disclaimer}</strong></p>
<h2>Extension to every source variable</h2><p>This expanded report retains all earlier age and platform and dispersion results and adds occupation, citizenship, listed languages, birth-date precision and birth cohorts, name–handle relationships, and identifier consistency. Birth date overlaps with age and is not entered beside it as a second independent demographic predictor. QID, item URL and property ID are identifiers, so they receive data-integrity audits rather than demographic significance tests.</p>
<h2>Coverage of additional metadata</h2>{htmltable(new['all_metadata_coverage'])}
<p>Fields separated by | are treated as sets of memberships. A person can appear in several occupation, citizenship or language categories; these categories overlap, and their sample sizes must not be summed as if they were disjoint populations. Within any category each original row contributes at most once. Exact-combination tables and counts of memberships are also supplied. Missing is analysed separately. Categories use original labels without silently merging countries, occupational roles or language variants.</p>'''
for field,title in [('occupations','Occupation'),('citizenships','Citizenship'),('languages','Listed languages')]:
 sections+=f'<h2>{title}: platform-specific results</h2><p>The 15 most frequent recorded categories are displayed here; every category, including rare labels, is present in the CSV tables. Counts are handle records, with unique-person counts also shown.</p>'+htmltable(displaysummary(field))
 if field=='languages':sections+='<p class="note">All listed-language metadata in this file belongs to X records; none is available for YouTube. Language-filtered results and models therefore apply only to the X subset. Listed languages do not establish native language, language proficiency, or the language used to create a handle. English, American English, Portuguese and Brazilian Portuguese remain distinct labels; missing language metadata is extensive. An apparent script or capitalization difference may reflect sample composition.</p>'
 if field=='citizenships':sections+='<p>Citizenship is neither ethnicity nor current residence. Historical jurisdictions and multiple citizenships remain as recorded. This report does not infer national cultural naming preferences from citizenship alone.</p>'
 if field=='occupations':sections+='<p>Occupations overlap and may refer to different career stages. Associations cannot establish that a profession caused a naming choice, or that the account was created for that professional activity.</p>'
sections+='<h2>Birth-date precision and birth cohorts</h2>'+htmltable(new['birth_year_summary'])+htmltable(new['birth_date_precision'][new['birth_date_precision'].feature=='length'][['platform','birth_date_precision','n','mean','sd']])+htmltable(new['birth_decades'][new['birth_decades'].feature=='length'][['platform','birth_decade','n','mean','sd']])
sections+='<p>Birth year is parsed only from valid YYYY, YYYY-MM or YYYY-MM-DD forms. Malformed or unparsed values remain labelled. A full-looking date may contain a conventional default month/day and is not proof of day-level source accuracy. Birth cohort contrasts are descriptive and are not independent replication of age effects. No collection date or date of death is supplied, so age metadata is not corrected or interpreted as age at account creation.</p>'
sections+='<h2>Names and handle resemblance</h2>'+htmltable(name)+'<p>Comparison applies Unicode NFKC normalization and case-folding, then retains alphanumeric characters. Three measures are computed among rows with a nonmissing label: normalized label equals handle, the complete normalized label is contained in the handle, and at least one label token of three or more normalized characters occurs as a substring in the handle. These are reproducible spelling heuristics, not validated given-name/surname extraction, verified real-name use, or identity attribution. Diacritics are not removed and names are not transliterated. Short tokens are excluded from token matching to reduce accidental matches. Generic or organizational labels can still match. Name length and token-count SDs and age-filtered summaries are in the downloadable tables.</p>'
sections+='<h2>Adjusted occupation, citizenship and language associations</h2>'+htmltable(a[a.feature=='length'])+'<p>Each category is compared with all other rows having metadata for that field. Separate regressions adjust for recorded age per decade and platform, with standard errors clustered by QID. Categories are chosen by the deterministic top-15 rule with at least 100 member records; at least 30 members and 30 nonmembers must remain for a fitted contrast. Outcomes include length, digit presence, terminal digit, underscore, lowercase, mixed case and non-ASCII characters. All category coefficients within each metadata field share one Holm adjustment. Binary outcomes use linear probability models; multiply coefficients by 100 to obtain percentage points. The models do not simultaneously control all occupations, citizenships or languages, and the complete-case sample may be selective. Report association sizes and confidence intervals rather than interpreting small p-values as strong explanatory power.</p>'
sections+='<p>For language models, only X records have available metadata. The platform predictor is therefore omitted as constant; those models adjust for age within X. Occupation and citizenship models include both platforms and adjust for platform. The platforms column records the analysed scope for each model.</p>'
sections+='<h2>Identifier and repeated-person checks</h2>'+htmltable(new['identifier_audit'])+htmltable(new['within_person_metadata_consistency'])+'<p>URL/QID agreement is a syntactic consistency check, not an independent verification of identity or ownership. Different values within a QID can reflect genuine multiple labels, changes, duplicates or errors. Unique QIDs are database entities and are not independently confirmed unique natural persons. Property mappings are audited as present in this file.</p>'
sections+='<h2>Interpretation for the dissertation</h2><p>The additional analyses support description of variation within Class B conditional on available metadata. They cannot resolve the original class-verification problem, establish demographic causation or validate inference about an individual. Platform stratification is necessary, overlapping categories must be made explicit, and rare cells should not support general claims. Complete-case results should be identified as such. No new Class C comparison, NER experiment, or classifier validation was conducted.</p><h2>Reproducibility of the extension</h2><p>Run <code>python analyze_platform_age.py INPUT.csv --output Class_B_Platform_Age</code> with both Python scripts together. Every original field is either analysed or audited. Full-precision tables include every metadata category and exact multi-value combination. Inferential selection and correction rules are specified above. The supplied source CSV is required and is not redistributed in this package.</p>'
report=(out/'Class_B_Report.html').read_text();report=report.replace('Class B platform and age analysis','Class B all-variable analysis');report=report.replace('<h1>Class B: platform and age analysis</h1>','<h1>Class B: all-variable analysis</h1><p class="note"><strong>'+disclaimer+'</strong></p>');report=report.replace('</body></html>',sections+'</body></html>');report=report.replace('Name inclusion and NER are not evaluated here: name segmentation would need its own validated procedure.','The original analysis did not evaluate names or NER. The extension below adds explicitly labelled name–handle spelling heuristics; it does not evaluate NER or validate name segmentation.')
from simple_report_text import simplify_report
report=simplify_report(report)
(out/'Class_B_Platform_Age_Report.html').write_text(report,encoding='utf-8');(out/'Class_B_Report.html').unlink()
(out/'Verification_Disclaimer.txt').write_text(disclaimer+'\n',encoding='utf-8');shutil.copyfile(__file__,out/'analyze_platform_age.py');shutil.copyfile(Path(__file__).with_name('platform_age_core.py'),out/'platform_age_core.py');shutil.copyfile(Path(__file__).with_name('class_b_graphs.py'),out/'class_b_graphs.py')
(out/'README.txt').write_text('Open Class_B_Platform_Age_Report.html. Charts are embedded. All CSV tables contain full numeric precision. Put both Python scripts together and run python analyze_platform_age.py INPUT.csv --output RESULTS_DIR to reproduce. Category memberships overlap; missing labels are not inferred. Read Verification_Disclaimer.txt. Original source CSV is not redistributed.\n',encoding='utf-8')
for f in metadata:
 assert new[f+'_category_counts'].n.sum()==d[f+'_membership_count'].sum()
assert new['name_relationships_by_platform'].query("feature == 'normalized_label_equals_handle'").n.sum()==nameknown.sum()
assert new['birth_date_precision'].query("feature == 'length'").n.sum()==len(d)
with zipfile.ZipFile(out.parent/'Class_B_Platform_Age_Results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.iterdir()):z.write(f,arcname='Class_B_Platform_Age/'+f.name)
print('All-variable tables, report, and ZIP completed; validation passed.')
print(name.to_string(index=False));print(a[(a.feature=='length')&(a.p_holm_field<.05)].sort_values('coefficient').head(12).to_string(index=False))
