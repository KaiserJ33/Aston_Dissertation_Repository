import argparse,base64,json
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from statistics_core import feature_frame,aggregate_frames,length_quantiles,grouped_summaries,COUNT_FEATURES,BINARY_FEATURES

parser=argparse.ArgumentParser();parser.add_argument('input');parser.add_argument('--output',default='class_a_results');args=parser.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
source=pd.read_csv(args.input);frame=feature_frame(source['Username']);n=len(frame)
if n<2:raise ValueError('At least two nonmissing usernames are required.')
summary,hist,moments,binary,total,unique=aggregate_frames([frame],'A',True)
mean=frame.length.mean();sd=frame.length.std(ddof=1)
for feature in COUNT_FEATURES:
 mask=summary.metric.eq(feature);se=frame[feature].std(ddof=1)/np.sqrt(n);half=stats.t.ppf(.975,n-1)*se
 summary.loc[mask,'se']=se;summary.loc[mask,'ci95_low']=frame[feature].mean()-half;summary.loc[mask,'ci95_high']=frame[feature].mean()+half
summary.to_csv(out/'class_a_feature_summary.csv',index=False)
q1,q2,q3=length_quantiles(hist);quartiles,bands=grouped_summaries([frame],q1,q2,q3,mean,sd)
quartiles.to_csv(out/'class_a_length_quartile_summary.csv',index=False);bands.to_csv(out/'class_a_length_sd_band_summary.csv',index=False)
quality=pd.DataFrame([{'records':n,'unique_usernames':unique,'repeated_username_records':n-unique,'missing_usernames':int(source.Username.isna().sum()),'mean_length':mean,'sd_length':sd,'below_sd_boundary':mean-sd,'above_sd_boundary':mean+sd}]);quality.to_csv(out/'record_summary.csv',index=False)
distinct=frame.drop_duplicates('username');sensitivity=pd.DataFrame([{'sample':'All records','n':n,'mean_length':mean,'sd_length':sd},{'sample':'Distinct username strings','n':len(distinct),'mean_length':distinct.length.mean(),'sd_length':distinct.length.std(ddof=1)}]);sensitivity.to_csv(out/'duplicate_sensitivity.csv',index=False)
plt.rcParams.update({'font.size':11})
fig,ax=plt.subplots(figsize=(9,4.5));ax.hist(frame.length,bins=np.arange(frame.length.min(),frame.length.max()+2)-.5,color='#245b88',edgecolor='white');ax.axvline(mean,color='#be591e',label=f'Mean: {mean:.2f}');ax.set(xlabel='Username length (characters)',ylabel='Number of records',title='Class A username lengths');ax.legend();fig.tight_layout();fig.savefig(out/'length_distribution.png',dpi=160);plt.close(fig)
features=['contains_digit','ends_with_digit','contains_underscore','contains_period','contains_other_special','all_lowercase','all_uppercase','mixed_case','camel_case','repeated_char_3plus'];labels=['Contains digit','Ends with digit','Underscore','Period','Other special character','Lowercase','Uppercase','Mixed case','CamelCase','Repeated character 3+']
fig,ax=plt.subplots(figsize=(9,5.5));rates=summary.set_index('metric').loc[features];rates=rates.iloc[::-1];ax.barh(labels[::-1],rates.mean_or_rate*100,color='#245b88');ax.errorbar(rates.mean_or_rate*100,labels[::-1],xerr=np.stack([(rates.mean_or_rate-rates.ci95_low)*100,(rates.ci95_high-rates.mean_or_rate)*100]),fmt='none',ecolor='#be591e',capsize=3);ax.set(xlabel='Percentage of records (95% confidence intervals)',title='Class A username features');fig.tight_layout();fig.savefig(out/'feature_rates.png',dpi=160);plt.close(fig)
disclaimer='Not all rows or their source details could be independently verified. Class A includes aliases collected from court documents and press releases. Some entries may be offline aliases rather than online handles, and source formatting may affect spelling, capitals, and punctuation. These results describe the supplied file. They cannot show that an individual username belongs to a criminal.'
(out/'Verification_Disclaimer.txt').write_text(disclaimer+'\n')
def table(x):return x.to_html(index=False,float_format=lambda v:f'{v:.4g}',border=0)
def image(name):return '<img style="max-width:100%;width:1000px" src="data:image/png;base64,'+base64.b64encode((out/name).read_bytes()).decode()+'">'
report='<html><head><meta charset="utf-8"><title>Class A username analysis</title><style>body{font:16px/1.5 Arial;max-width:1100px;margin:40px auto;padding:0 24px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:left}th{background:#edf3f8}.note{background:#fff2d8;padding:16px}</style></head><body><h1>Class A: username patterns</h1><p class="note">'+disclaimer+'</p>'
report+='<h2>Records and length</h2><p>The main descriptions include all nonmissing username records. Repeated username strings are kept so that the results match the earlier Class A analysis. They may occur in different source records; they are not automatically treated as data errors.</p>'+table(quality)+image('length_distribution.png')
report+='<h2>Structural features</h2><p>The table gives character counts and the frequency of yes/no features. For counts, mean_or_rate is the average. For yes/no features, multiply mean_or_rate by 100 to get a percentage. SD shows variation between records. SE shows uncertainty in an estimated average. ci95_low and ci95_high are the ends of a 95% confidence interval. The records and unique_usernames rows are totals, not averages.</p>'+table(summary)+image('feature_rates.png')
report+='<h2>Length groups</h2><p>The first table groups lengths using quartile cutoffs. Tied lengths stay together, so groups may have different sizes. The second groups lengths below the mean minus one SD, within one SD, and above the mean plus one SD. Boundary values go in the middle group. These are length groups, not groups of people.</p>'+table(quartiles)+table(bands)
report+='<h2>Repeated username check</h2><p>This table compares all records with one copy of each exact username string. A unique string does not necessarily identify a unique person.</p>'+table(sensitivity)
report+='<h2>How the measures are calculated</h2><p>Handles are kept as supplied. Length counts Unicode code points. Letter, digit, vowel, punctuation, and CamelCase measures use the same ASCII-based rules as the earlier Class A analysis. This differs from the Unicode-aware letter and digit checks in the Class B package. Other special characters exclude underscores and periods. CamelCase means a lowercase ASCII letter followed by an uppercase letter. A repetition means the same character appears at least three times in a row.</p><p>SD uses the sample formula (ddof=1). Mean intervals use the t distribution; percentage intervals use the Wilson method. These intervals treat records as separate observations. Repeated people and cases may limit that assumption. The intervals do not correct unverified sources or biased selection.</p>'
report+='<h2>Scope</h2><p>This package reproduces the Class A structural descriptions. It does not add age or gender comparisons, audit the source claims, rerun NER, or train a classifier. Differences in capitals or punctuation may reflect source formatting rather than a naming choice. No new Class A–Class C tests are made here.</p><h2>Rerunning the analysis</h2><p>Keep both Python files together and run python analyze_class_a.py INPUT.csv --output RESULTS_DIR. You need the original CSV, with its Username column, and Python with numpy, pandas, scipy, and matplotlib. Raw usernames and personal details are not included in this results package.</p></body></html>'
(out/'Class_A_Report.html').write_text(report)
assert bands.query("metric == 'length'").n.sum()==n
print(f'Class A complete: {n} records, {unique} distinct strings, mean {mean:.6f}, SD {sd:.6f}')
