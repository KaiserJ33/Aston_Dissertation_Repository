from __future__ import annotations
import argparse
import json
import math
import re
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, t as student_t
BINARY_FEATURES = ['contains_digit', 'ends_with_digit', 'starts_with_letter', 'contains_underscore', 'contains_period', 'contains_other_special', 'all_lowercase', 'all_uppercase', 'mixed_case', 'camel_case', 'repeated_char_3plus']
COUNT_FEATURES = ['length', 'digit_count', 'letter_count', 'vowel_count', 'special_count', 'delimiter_piece_count']

def find_username_column(columns: list[str], preferred: str | None=None) -> str:
    if preferred:
        for col in columns:
            if str(col).strip().lower() == preferred.strip().lower():
                return col
        raise ValueError(f'Requested username column {preferred!r} was not found: {columns}')
    candidates = ['username', 'user_name', 'handle', 'user', 'author', 'name']
    lowered = {str(col).strip().lower(): col for col in columns}
    for candidate in candidates:
        if candidate in lowered:
            return lowered[candidate]
    raise ValueError(f'Could not identify a username column. Columns: {columns}')

def clean_strings(series: pd.Series) -> pd.Series:
    return series.dropna().astype(str)

def feature_frame(series: pd.Series) -> pd.DataFrame:
    s = clean_strings(series)
    frame = pd.DataFrame(index=s.index)
    frame['username'] = s
    frame['length'] = s.str.len().astype(np.int64)
    frame['digit_count'] = s.str.count('[0-9]').astype(np.int64)
    frame['letter_count'] = s.str.count('[A-Za-z]').astype(np.int64)
    frame['vowel_count'] = s.str.count('[AEIOUaeiou]').astype(np.int64)
    frame['special_count'] = s.str.count('[^A-Za-z0-9]').astype(np.int64)
    frame['delimiter_piece_count'] = s.str.split('[_\\.\\-\\s]+', regex=True).map(lambda parts: sum((bool(x) for x in parts))).astype(np.int64)
    frame['contains_digit'] = s.str.contains('[0-9]', regex=True)
    frame['ends_with_digit'] = s.str.contains('[0-9]$', regex=True)
    frame['starts_with_letter'] = s.str.contains('^[A-Za-z]', regex=True)
    frame['contains_underscore'] = s.str.contains('_', regex=False)
    frame['contains_period'] = s.str.contains('.', regex=False)
    frame['contains_other_special'] = s.str.contains('[^A-Za-z0-9_.]', regex=True)
    frame['all_lowercase'] = s.map(str.islower)
    frame['all_uppercase'] = s.map(str.isupper)
    frame['mixed_case'] = s.str.contains('[A-Z]', regex=True) & s.str.contains('[a-z]', regex=True)
    frame['camel_case'] = s.str.contains('[a-z][A-Z]', regex=True)
    frame['repeated_char_3plus'] = s.map(lambda value: bool(re.search('(.)\\1\\1', value)))
    return frame

class RunningMoments:

    def __init__(self) -> None:
        self.n = 0
        self.total = 0.0
        self.total_sq = 0.0

    def update(self, values: pd.Series) -> None:
        arr = values.to_numpy(dtype=float)
        self.n += int(arr.size)
        self.total += float(arr.sum())
        self.total_sq += float(np.square(arr).sum())

    @property
    def mean(self) -> float:
        return self.total / self.n if self.n else math.nan

    @property
    def variance(self) -> float:
        if self.n < 2:
            return math.nan
        return max(0.0, (self.total_sq - self.total * self.total / self.n) / (self.n - 1))

    @property
    def sd(self) -> float:
        return math.sqrt(self.variance)

def wilson_interval(successes: int, n: int, z: float=1.959963984540054) -> tuple[float, float]:
    if n == 0:
        return (math.nan, math.nan)
    p = successes / n
    denominator = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denominator
    return (center - half, center + half)

def length_quantiles(histogram: Counter[int]) -> tuple[int, int, int]:
    n = sum(histogram.values())
    cutoffs = []
    for q in (0.25, 0.5, 0.75):
        target = q * (n - 1)
        cumulative = 0
        chosen = None
        for value in sorted(histogram):
            cumulative += histogram[value]
            if cumulative - 1 >= target:
                chosen = value
                break
        cutoffs.append(chosen if chosen is not None else max(histogram))
    return tuple(cutoffs)

def summary_rows(class_name: str, n: int, unique_n: int | None, moments: dict[str, RunningMoments], binary: Counter[str]) -> list[dict]:
    rows: list[dict] = [{'class': class_name, 'metric': 'records', 'count': n, 'mean_or_rate': n, 'sd': '', 'ci95_low': '', 'ci95_high': ''}, {'class': class_name, 'metric': 'unique_usernames', 'count': unique_n if unique_n is not None else 'not calculated', 'mean_or_rate': unique_n if unique_n is not None else '', 'sd': '', 'ci95_low': '', 'ci95_high': ''}]
    for feature in COUNT_FEATURES:
        m = moments[feature]
        rows.append({'class': class_name, 'metric': feature, 'count': m.n, 'mean_or_rate': m.mean, 'sd': m.sd, 'ci95_low': '', 'ci95_high': ''})
    for feature in BINARY_FEATURES:
        successes = int(binary[feature])
        low, high = wilson_interval(successes, n)
        p = successes / n
        rows.append({'class': class_name, 'metric': feature, 'count': successes, 'mean_or_rate': p, 'sd': math.sqrt(p * (1 - p) * n / (n - 1)) if n > 1 else math.nan, 'ci95_low': low, 'ci95_high': high})
    return rows

def aggregate_frames(frames, class_name: str, calculate_unique: bool) -> tuple[pd.DataFrame, Counter[int], dict[str, RunningMoments], Counter[str], int, int | None]:
    histogram: Counter[int] = Counter()
    moments = {feature: RunningMoments() for feature in COUNT_FEATURES}
    binary: Counter[str] = Counter()
    unique_values: set[str] | None = set() if calculate_unique else None
    n = 0
    for frame in frames:
        n += len(frame)
        histogram.update(frame['length'].astype(int).tolist())
        for feature in COUNT_FEATURES:
            moments[feature].update(frame[feature])
        for feature in BINARY_FEATURES:
            binary[feature] += int(frame[feature].sum())
        if unique_values is not None:
            unique_values.update(frame['username'].tolist())
    rows = summary_rows(class_name, n, len(unique_values) if unique_values is not None else None, moments, binary)
    return (pd.DataFrame(rows), histogram, moments, binary, n, len(unique_values) if unique_values is not None else None)

def summarize_group(frame: pd.DataFrame, group_name: str, group_value: str) -> list[dict]:
    n = len(frame)
    rows = []
    for feature in COUNT_FEATURES:
        rows.append({'grouping': group_name, 'group': group_value, 'metric': feature, 'n': n, 'mean_or_rate': frame[feature].mean(), 'sd': frame[feature].std(ddof=1)})
    for feature in BINARY_FEATURES:
        rows.append({'grouping': group_name, 'group': group_value, 'metric': feature, 'n': n, 'mean_or_rate': frame[feature].mean(), 'sd': frame[feature].std(ddof=1)})
    return rows

def add_length_groups(frame: pd.DataFrame, q1: int, q2: int, q3: int, mean: float, sd: float) -> pd.DataFrame:
    out = frame.copy()
    out['length_quartile'] = pd.cut(out['length'], bins=[-np.inf, q1, q2, q3, np.inf], labels=['Q1 shortest', 'Q2', 'Q3', 'Q4 longest'], include_lowest=True)
    lower, upper = (mean - sd, mean + sd)
    out['length_sd_band'] = np.select([out['length'] < lower, out['length'] > upper], ['Below mean - 1 SD', 'Above mean + 1 SD'], default='Within 1 SD')
    return out

def grouped_summaries(frames, q1: int, q2: int, q3: int, mean: float, sd: float) -> tuple[pd.DataFrame, pd.DataFrame]:

    def new_stats() -> dict:
        return {'n': 0, 'moments': {feature: RunningMoments() for feature in COUNT_FEATURES}, 'binary': Counter()}

    def update_group(bucket: dict[str, dict], label: str, subset: pd.DataFrame) -> None:
        if label not in bucket:
            bucket[label] = new_stats()
        stats = bucket[label]
        stats['n'] += len(subset)
        for feature in COUNT_FEATURES:
            stats['moments'][feature].update(subset[feature])
        for feature in BINARY_FEATURES:
            stats['binary'][feature] += int(subset[feature].sum())

    def final_rows(bucket: dict[str, dict], grouping: str, order: list[str]) -> pd.DataFrame:
        rows: list[dict] = []
        for label in order:
            if label not in bucket:
                continue
            stats = bucket[label]
            n = stats['n']
            for feature in COUNT_FEATURES:
                m = stats['moments'][feature]
                rows.append({'grouping': grouping, 'group': label, 'metric': feature, 'n': n, 'mean_or_rate': m.mean, 'sd': m.sd})
            for feature in BINARY_FEATURES:
                successes = stats['binary'][feature]
                p = successes / n
                rows.append({'grouping': grouping, 'group': label, 'metric': feature, 'n': n, 'mean_or_rate': p, 'sd': math.sqrt(p * (1 - p) * n / (n - 1)) if n > 1 else math.nan})
        return pd.DataFrame(rows)
    quartile_stats: dict[str, dict] = {}
    sd_stats: dict[str, dict] = {}
    for frame in frames:
        grouped = add_length_groups(frame, q1, q2, q3, mean, sd)
        for group, subset in grouped.groupby('length_quartile', observed=False):
            if len(subset):
                update_group(quartile_stats, str(group), subset)
        for group, subset in grouped.groupby('length_sd_band', observed=False):
            if len(subset):
                update_group(sd_stats, str(group), subset)
    return (final_rows(quartile_stats, 'length_quartile', ['Q1 shortest', 'Q2', 'Q3', 'Q4 longest']), final_rows(sd_stats, 'length_sd_band', ['Below mean - 1 SD', 'Within 1 SD', 'Above mean + 1 SD']))

def holm_adjust(p_values: list[float]) -> list[float]:
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    m = len(p_values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (m - rank) * p_values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()

def binary_tests(a_binary: Counter[str], a_n: int, c_binary: Counter[str], c_n: int) -> pd.DataFrame:
    rows = []
    for feature in BINARY_FEATURES:
        a_yes, c_yes = (int(a_binary[feature]), int(c_binary[feature]))
        odds_ratio, p = fisher_exact([[a_yes, a_n - a_yes], [c_yes, c_n - c_yes]])
        p_a, p_c = (a_yes / a_n, c_yes / c_n)
        h = 2 * math.asin(math.sqrt(p_a)) - 2 * math.asin(math.sqrt(p_c))
        rows.append({'feature': feature, 'class_a_count': a_yes, 'class_a_rate': p_a, 'class_c_count': c_yes, 'class_c_rate': p_c, 'rate_difference_a_minus_c': p_a - p_c, 'odds_ratio': odds_ratio, 'cohen_h': h, 'p_value_fisher': p})
    adjusted = holm_adjust([row['p_value_fisher'] for row in rows])
    for row, value in zip(rows, adjusted):
        row['p_value_holm'] = value
    return pd.DataFrame(rows)

def welch_from_summary(mean1: float, sd1: float, n1: int, mean2: float, sd2: float, n2: int) -> tuple[float, float, float]:
    v1, v2 = (sd1 * sd1 / n1, sd2 * sd2 / n2)
    se = math.sqrt(v1 + v2)
    t_stat = (mean1 - mean2) / se
    df = (v1 + v2) ** 2 / (v1 * v1 / (n1 - 1) + v2 * v2 / (n2 - 1))
    p = 2 * student_t.sf(abs(t_stat), df)
    return (t_stat, df, p)

def continuous_tests(a_moments: dict[str, RunningMoments], c_moments: dict[str, RunningMoments]) -> pd.DataFrame:
    rows = []
    for feature in COUNT_FEATURES:
        a, c = (a_moments[feature], c_moments[feature])
        t_stat, df, p = welch_from_summary(a.mean, a.sd, a.n, c.mean, c.sd, c.n)
        pooled = math.sqrt(((a.n - 1) * a.variance + (c.n - 1) * c.variance) / (a.n + c.n - 2))
        d = (a.mean - c.mean) / pooled if pooled else math.nan
        rows.append({'feature': feature, 'class_a_mean': a.mean, 'class_a_sd': a.sd, 'class_a_n': a.n, 'class_c_mean': c.mean, 'class_c_sd': c.sd, 'class_c_n': c.n, 'mean_difference_a_minus_c': a.mean - c.mean, 'welch_t': t_stat, 'welch_df': df, 'p_value': p, 'cohen_d': d})
    return pd.DataFrame(rows)

def csv_chunks(path: Path, username_column: str | None, chunk_size: int):
    header = pd.read_csv(path, nrows=0)
    column = find_username_column(header.columns.tolist(), username_column)
    for chunk in pd.read_csv(path, usecols=[column], chunksize=chunk_size):
        yield feature_frame(chunk[column])

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--class-a', required=True, type=Path)
    parser.add_argument('--class-c', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--class-a-column')
    parser.add_argument('--class-c-column')
    parser.add_argument('--chunk-size', type=int, default=500000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    a_raw = pd.read_csv(args.class_a)
    a_column = find_username_column(a_raw.columns.tolist(), args.class_a_column)
    a_frame = feature_frame(a_raw[a_column])
    a_summary, a_hist, a_moments, a_binary, a_n, a_unique = aggregate_frames([a_frame], 'A', True)
    a_q = length_quantiles(a_hist)
    a_quartiles, a_sd_bands = grouped_summaries([a_frame], *a_q, a_moments['length'].mean, a_moments['length'].sd)
    c_summary, c_hist, c_moments, c_binary, c_n, _ = aggregate_frames(csv_chunks(args.class_c, args.class_c_column, args.chunk_size), 'C', False)
    c_q = length_quantiles(c_hist)
    c_quartiles, c_sd_bands = grouped_summaries(csv_chunks(args.class_c, args.class_c_column, args.chunk_size), *c_q, c_moments['length'].mean, c_moments['length'].sd)
    a_summary.to_csv(args.output_dir / 'class_a_feature_summary.csv', index=False)
    c_summary.to_csv(args.output_dir / 'class_c_feature_summary.csv', index=False)
    a_quartiles.to_csv(args.output_dir / 'class_a_length_quartile_summary.csv', index=False)
    c_quartiles.to_csv(args.output_dir / 'class_c_length_quartile_summary.csv', index=False)
    a_sd_bands.to_csv(args.output_dir / 'class_a_length_sd_band_summary.csv', index=False)
    c_sd_bands.to_csv(args.output_dir / 'class_c_length_sd_band_summary.csv', index=False)
    binary_tests(a_binary, a_n, c_binary, c_n).to_csv(args.output_dir / 'class_a_vs_c_binary_tests.csv', index=False)
    continuous_tests(a_moments, c_moments).to_csv(args.output_dir / 'class_a_vs_c_continuous_tests.csv', index=False)
    configuration = {'class_a_file': str(args.class_a), 'class_c_file': str(args.class_c), 'class_a_username_column': a_column, 'class_c_username_column': args.class_c_column or 'auto-detected', 'class_a_records': a_n, 'class_a_unique_usernames': a_unique, 'class_c_records': c_n, 'chunk_size': args.chunk_size, 'class_a_length_quartile_cutoffs': a_q, 'class_c_length_quartile_cutoffs': c_q, 'feature_definitions': {'contains_other_special': 'any character other than ASCII letter, digit, underscore, or period', 'all_lowercase': 'Python str.islower: at least one cased character and no uppercase cased character', 'all_uppercase': 'Python str.isupper: at least one cased character and no lowercase cased character', 'mixed_case': 'contains at least one ASCII uppercase and one ASCII lowercase letter', 'camel_case': 'contains an ASCII lowercase-to-uppercase transition', 'repeated_char_3plus': 'same character repeated at least three times consecutively', 'sd_for_binary_features': 'sample SD of the 0/1 indicator; Wilson 95% CI is also reported'}}
    (args.output_dir / 'analysis_configuration.json').write_text(json.dumps(configuration, indent=2), encoding='utf-8')
    print(f'Wrote results to {args.output_dir}')
if __name__ == '__main__':
    main()
