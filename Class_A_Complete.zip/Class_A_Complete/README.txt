Open results/Class_A_Report.html. Both graphs are embedded. CSV tables and separate PNG graphs are in results/.

To reproduce, keep the Python files together in code/ and run:
python code/analyze_class_a.py "PATH/TO/Class_A_Criminal_Usernames_Master_Database.csv" --output rerun_results

Requires Python 3, numpy, pandas, scipy, and matplotlib. Use your original source CSV; it is not included. No raw handles, names, source URLs, or row-level personal details are included.

The primary descriptions reproduce the earlier 236-record Class A results. They retain repeated strings; 234 exact strings are distinct. The report adds mean confidence intervals, graphs, and a duplicate sensitivity summary. It contains no analysis date. Code contains no comments or docstrings. Read results/Verification_Disclaimer.txt for the source limitations.
