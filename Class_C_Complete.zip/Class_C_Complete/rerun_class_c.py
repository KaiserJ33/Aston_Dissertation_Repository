from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
import original_statistics as original
OUTPUTS = ('class_c_feature_summary.csv', 'class_c_length_quartile_summary.csv', 'class_c_length_sd_band_summary.csv')
EXPECTED_N = 25865739

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def validate_groups(summary, grouped, expected_n):
    overall = summary.set_index('metric')
    if grouped.duplicated(['group', 'metric']).any():
        raise ValueError('Duplicate group/metric rows: aggregation failed.')
    metrics = original.COUNT_FEATURES + original.BINARY_FEATURES
    if set(grouped.metric) != set(metrics):
        raise ValueError('Grouped metrics are missing or unexpected.')
    for group, block in grouped.groupby('group'):
        if set(block.metric) != set(metrics) or block.n.nunique() != 1:
            raise ValueError(f'Inconsistent metrics or denominators in {group}.')
    for metric in metrics:
        rows = grouped[grouped.metric == metric]
        n = rows.n.to_numpy(dtype=float)
        means = rows.mean_or_rate.to_numpy(dtype=float)
        sds = rows.sd.to_numpy(dtype=float)
        if int(n.sum()) != expected_n:
            raise ValueError(f'{metric}: band totals do not equal the full corpus.')
        mean = float((n * means).sum() / n.sum())
        target_mean = float(overall.loc[metric, 'mean_or_rate'])
        target_sd = float(overall.loc[metric, 'sd'])
        within = np.where(n > 1, (n - 1) * np.nan_to_num(sds) ** 2, 0).sum()
        pooled_sd = math.sqrt(float((within + (n * (means - mean) ** 2).sum()) / (n.sum() - 1)))
        if not math.isclose(mean, target_mean, rel_tol=1e-10, abs_tol=1e-10):
            raise ValueError(f'{metric}: grouped means do not reproduce the overall mean.')
        if not math.isclose(pooled_sd, target_sd, rel_tol=1e-09, abs_tol=1e-09):
            raise ValueError(f'{metric}: grouped SDs do not reproduce the overall SD.')

def compare_reference(actual, reference, keys):
    if set(actual.columns) != set(reference.columns):
        return ['Column names differ.']
    if actual.duplicated(keys).any() or reference.duplicated(keys).any():
        return ['Duplicate comparison keys.']
    a = actual.set_index(keys).sort_index()
    b = reference.set_index(keys).sort_index()
    if not a.index.equals(b.index):
        return ['Metric/group keys differ.']
    mismatches = []
    for column in a.columns:
        for key in a.index:
            x, y = (a.at[key, column], b.at[key, column])
            if pd.isna(x) and pd.isna(y):
                continue
            try:
                equal = math.isclose(float(x), float(y), rel_tol=1e-10, abs_tol=1e-10)
            except (ValueError, TypeError):
                equal = str(x) == str(y)
            if not equal:
                mismatches.append(f'{key} / {column}: rerun={x!r}, reference={y!r}')
    return mismatches

def run(args):
    if args.chunk_size <= 0:
        raise ValueError('--chunk-size must be positive.')
    if not args.input.is_file():
        raise ValueError(f'Input not found: {args.input}')
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise ValueError('Choose a new or empty output directory; existing results are not overwritten.')
    before = sha256(args.input)

    def frames(pass_number):
        count = 0
        for frame in original.csv_chunks(args.input, args.column, args.chunk_size):
            count += len(frame)
            if count == len(frame) or count % (args.chunk_size * 5) == 0:
                print(f'Pass {pass_number}: {count:,} eligible records', flush=True)
            yield frame
        print(f'Pass {pass_number} complete: {count:,} eligible records', flush=True)
    summary, hist, moments, binary, n, _ = original.aggregate_frames(frames(1), 'C', False)
    if n < 2:
        raise ValueError('At least two eligible username records are required.')
    if not args.exploratory and n != EXPECTED_N:
        raise ValueError(f'Expected {EXPECTED_N:,} eligible records but found {n:,}. Check for truncated or different input. No results have been saved.')
    quartiles = original.length_quantiles(hist)
    if len(set(quartiles)) != 3:
        raise ValueError('Quartile cutoffs coincide; the historical four-band method is not applicable to this input.')
    mean, sd = (moments['length'].mean, moments['length'].sd)
    q_table, sd_table = original.grouped_summaries(frames(2), *quartiles, mean, sd)
    after = sha256(args.input)
    if before != after:
        raise ValueError('Input file changed during the run; results were not saved.')
    validate_groups(summary, q_table, n)
    validate_groups(summary, sd_table, n)
    tables = (summary, q_table, sd_table)
    comparisons = {}
    if not args.exploratory:
        for name, table in zip(OUTPUTS, tables):
            reference = pd.read_csv(args.reference_dir / name)
            keys = ['metric'] if name == OUTPUTS[0] else ['group', 'metric']
            comparisons[name] = compare_reference(table, reference, keys)
    matched = not args.exploratory and all((not v for v in comparisons.values()))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, table in zip(OUTPUTS, tables):
        table.to_csv(args.output_dir / name, index=False)
    pd.DataFrame(sorted(hist.items()), columns=['length', 'n']).to_csv(args.output_dir / 'class_c_length_histogram.csv', index=False)
    report = {'status': 'MATCHED_REFERENCE' if matched else 'EXPLORATORY_ONLY' if args.exploratory else 'REFERENCE_MISMATCH', 'created_utc': datetime.now(timezone.utc).isoformat(), 'records': n, 'input_path': str(args.input.resolve()), 'input_sha256': before, 'input_unchanged_during_run': True, 'username_column': args.column, 'chunk_size': args.chunk_size, 'parser': 'Original pandas.read_csv defaults; default NA recognition retained; no stripping or deduplication.', 'length_quartile_cutoffs': list(quartiles), 'sd_band_thresholds': [mean - sd, mean + sd], 'length_min': min(hist), 'length_max': max(hist), 'quartile_records': q_table[q_table.metric == 'length'][['group', 'n']].to_dict('records'), 'sd_band_records': sd_table[sd_table.metric == 'length'][['group', 'n']].to_dict('records'), 'integrity_checks': 'Passed band coverage, unique group/metric keys, reconstructed means and SDs.', 'reference_comparison_mismatches': comparisons, 'versions': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__}, 'code_sha256': {p.name: sha256(p) for p in [Path(__file__), Path(original.__file__)]}, 'historical_raw_file_hash_available': False}
    (args.output_dir / 'validation_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(report['status'], flush=True)
    print(f'Results: {args.output_dir.resolve()}', flush=True)
    return 0 if matched or args.exploratory else 1

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True, help='Original single-member ZIP, CSV, or CSV.GZ')
    p.add_argument('--column', default='author')
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--chunk-size', type=int, default=500000)
    p.add_argument('--reference-dir', type=Path, default=Path(__file__).resolve().parent / 'reference_outputs')
    p.add_argument('--exploratory', action='store_true', help='Disable historical row-count/reference checks; never claims reproduction')
    args = p.parse_args()
    try:
        return run(args)
    except (ValueError, OSError, KeyError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 1
if __name__ == '__main__':
    sys.exit(main())
