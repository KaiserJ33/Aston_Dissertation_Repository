import argparse, hashlib, json, re, shutil, zipfile, sys, base64
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser=argparse.ArgumentParser()
parser.add_argument('input', nargs='?', default='upload/Class_B_X_YouTube_Final(1).csv')
parser.add_argument('--output', default='Class_B_Platform_Age')
args=parser.parse_args(); out=Path(args.output); out.mkdir(exist_ok=True,parents=True)
d=pd.read_csv(args.input,dtype={'handle':str,'qid':str},keep_default_na=False)
d=d.drop(columns=['gender']);d['age']=pd.to_numeric(d.age,errors='coerce'); s=d.handle
continuous=['length','letter_count','digit_count','separator_count']
d['length']=s.str.len();d['letter_count']=s.map(lambda x:sum(c.isalpha() for c in x));d['digit_count']=s.map(lambda x:sum(c.isdigit() for c in x));d['separator_count']=s.map(lambda x:sum(c in '_.-' for c in x))
funcs={'starts_letter':lambda x:bool(x) and x[0].isalpha(),'contains_digit':lambda x:any(c.isdigit() for c in x),'ends_digit':lambda x:bool(x) and x[-1].isdigit(),'underscore':lambda x:'_' in x,'period':lambda x:'.' in x,'hyphen':lambda x:'-' in x,'other_special':lambda x:any(not c.isalnum() and c not in '_.' for c in x),'lowercase':str.islower,'uppercase':str.isupper,'mixed_case':lambda x:any(c.islower() for c in x) and any(c.isupper() for c in x),'camelcase_ascii':lambda x:bool(re.search('[a-z][A-Z]',x)),'numeric_only':str.isdigit,'repeated_3plus':lambda x:bool(re.search(r'(.)\1{2,}',x)),'non_ascii':lambda x:any(ord(c)>127 for c in x),'whitespace':lambda x:any(c.isspace() for c in x)}
binary=list(funcs)
for k,f in funcs.items():d[k]=s.map(f).astype(int)
d['age_band']=pd.cut(d.age,[-np.inf,17,29,39,49,59,69,100,np.inf],labels=['Under 18','18–29','30–39','40–49','50–59','60–69','70–100','Over 100']).astype(str)
d.loc[d.age.isna(),'age_band']='Missing'
def holm(p):
 p=np.asarray(p);ix=np.argsort(p);a=np.maximum.accumulate((len(p)-np.arange(len(p)))*p[ix]);r=np.empty(len(p));r[ix]=np.minimum(a,1);return r
def summary(frame,group_cols):
 rows=[]
 groups=[('All',frame)] if not group_cols else frame.groupby(group_cols,dropna=False,sort=True)
 for key,g in groups:
  keys=key if isinstance(key,tuple) else (key,)
  base=dict(zip(group_cols or ['group'],keys));base.update(n=len(g),unique_people=g.qid.nunique())
  for f in continuous:
   x=g[f];n=len(x);sd=x.std(ddof=1);se=sd/np.sqrt(n);ci=stats.t.ppf(.975,n-1)*se if n>1 else np.nan
   rows.append(dict(base,feature=f,mean=x.mean(),sd=sd,se=se,ci_low=x.mean()-ci,ci_high=x.mean()+ci,median=x.median(),q1=x.quantile(.25),q3=x.quantile(.75),minimum=x.min(),maximum=x.max()))
  for f in binary:
   n=len(g);k=int(g[f].sum());p=k/n;z=stats.norm.ppf(.975);den=1+z*z/n;ctr=(p+z*z/(2*n))/den;half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
   rows.append(dict(base,feature=f,count=k,percent=100*p,sd=g[f].std(ddof=1),ci_low=100*(ctr-half),ci_high=100*(ctr+half)))
 return pd.DataFrame(rows)
def htmltable(frame):return frame.to_html(index=False,float_format=lambda x:f'{x:.4g}',border=0)
tables={}
def save(name,frame):tables[name]=frame;frame.to_csv(out/(name+'.csv'),index=False)
for name,cols in [('overall',[]),('by_platform',['platform']),('by_age',['age_band']),('by_platform_age',['platform','age_band'])]:save(name,summary(d,cols))
save('metadata_coverage',pd.DataFrame([dict(platform=p,n=len(g),age_known=g.age.notna().sum(),age_over_100=(g.age>100).sum(),unique_people=g.qid.nunique()) for p,g in d.groupby('platform')]))
bands=[]
for p,g in [('All',d)]+list(d.groupby('platform')):
 mu=g.length.mean();sd=g.length.std(ddof=1);g=g.copy();g['length_band']=np.where(g.length<mu-sd,'Below -1 SD',np.where(g.length>mu+sd,'Above +1 SD','Within 1 SD'));q=summary(g,['length_band']);q['platform']=p;q['threshold_low']=mu-sd;q['threshold_high']=mu+sd;bands.append(q)
save('length_sd_bands',pd.concat(bands,ignore_index=True))
rows=[]
for p,g in [('All',d)]+list(d.groupby('platform')):
 g=g[g.age.between(0,100)]
 for f in continuous+binary:
  if g[f].nunique()<2:continue
  r=stats.spearmanr(g.age,g[f]);rows.append(dict(platform=p,feature=f,n=len(g),rho=r.statistic,p=r.pvalue))
a=pd.DataFrame(rows);a['p_holm']=a.groupby('platform').p.transform(holm);save('age_correlations',a)
models=[]
for platform,g in [('All',d[d.age.between(0,100)])]+list(d[d.age.between(0,100)].groupby('platform')):
 predictors=[np.ones(len(g)),(g.age-40)/10];terms=['Intercept','Age per 10 recorded years']
 if platform=='All':predictors.append((g.platform=='youtube_handle').astype(float));terms.append('YouTube minus X')
 X=np.column_stack(predictors);k=X.shape[1];inv=np.linalg.inv(X.T@X);cl=pd.factorize(g.qid)[0];ng=len(np.unique(cl))
 for f in continuous+binary:
  y=g[f].to_numpy(float);coef=inv@X.T@y;res=y-X@coef;sc=np.zeros((ng,k));np.add.at(sc,cl,X*res[:,None]);cv=ng/(ng-1)*(len(g)-1)/(len(g)-k)*inv@(sc.T@sc)@inv;se=np.sqrt(np.maximum(np.diag(cv),0));crit=stats.t.ppf(.975,ng-1)
  assert np.allclose(coef,np.linalg.lstsq(X,y,rcond=None)[0],atol=1e-8)
  for j in range(1,k):models.append(dict(platform=platform,feature=f,term=terms[j],n=len(g),clusters=ng,coefficient=coef[j],se=se[j],ci_low=coef[j]-crit*se[j],ci_high=coef[j]+crit*se[j],p=2*stats.t.sf(abs(coef[j]/se[j]),ng-1) if se[j]>0 else np.nan))
m=pd.DataFrame(models);valid=m.p.notna();m.loc[valid,'p_holm_all']=holm(m.loc[valid,'p']);save('age_platform_models',m)
sens=[]
for label,g in [('All records',d),('Unique platform-handle',d.drop_duplicates(['platform','handle'])),('One row per person-platform',d.sort_values(['qid','platform','handle']).drop_duplicates(['qid','platform'])),('Recorded age 18–80',d[d.age.between(18,80)])]:
 q=summary(g,['platform']);q['sensitivity']=label;sens.append(q)
save('sensitivity',pd.concat(sens,ignore_index=True));save('age_missingness',summary(d.assign(age_status=np.where(d.age.isna(),'Missing','Recorded')),['platform','age_status']))
report='''<!doctype html><html><head><meta charset="utf-8"><title>Class B platform and age analysis</title><style>body{font:16px/1.5 Arial,sans-serif;max-width:1100px;margin:40px auto;padding:0 24px;color:#172536}table{border-collapse:collapse;font-size:14px;width:100%;margin:20px 0}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:left}th{background:#eaf1f7}.note{padding:16px;background:#fff2d8}</style></head><body><h1>Class B: platform and age analysis</h1>'''
report+='<p>Platform is the primary grouping variable, with recorded age examined within each platform. All models and complete-case filters use only the variables specified for the model. No additional demographic-label restriction is imposed.</p>'
report+='<h2>Platform descriptions</h2>'+htmltable(tables['by_platform'])+'<h2>Age coverage</h2>'+htmltable(tables['metadata_coverage'])+'<h2>Age-filtered length results</h2>'+htmltable(tables['by_platform_age'].query("feature == 'length'"))
report+='<h2>Age and platform models</h2>'+htmltable(m[m.feature=='length'])+'<p>OLS and binary linear probability models use recorded ages 0–100. Standard errors cluster on QID. Pooled models adjust for platform; within-platform models estimate separate age associations. Linear slopes simplify the age-band patterns and do not establish causation. Binary coefficients are probability differences; multiply by 100 for percentage points. Holm correction covers all finite non-intercept p-values in this model family. Constant outcomes have undefined p-values.</p>'
report+='<h2>One-standard-deviation length bands</h2>'+htmltable(tables['length_sd_bands'].query("feature == 'length'"))+'<p>SD is the sample standard deviation (ddof=1). Continuous summaries report t-based 95% mean intervals. Binary summaries report percentages, indicator SD and Wilson intervals. Descriptive intervals are record-level; adjusted models use clustered standard errors. Bands use strict outer thresholds and inclusive middle thresholds separately for pooled and platform-specific distributions. One-SD bands need not contain 68% of a discrete non-normal distribution.</p>'
report+='<h2>Sensitivity checks</h2>'+htmltable(tables['sensitivity'].query("feature == 'length'"))+'<p>Recorded age is not age at account creation. Ages over 100 are retained separately in descriptions and excluded from age models. No missing values are imputed. Source handles are retained as supplied; Unicode-aware character tests and code-point length are used. CamelCase is an ASCII lower-to-upper transition. Other special characters exclude underscores and periods but include hyphens.</p>'
report+='</body></html>'
from class_b_graphs import restore_graphs
report=restore_graphs(d,out,report)
(out/'Class_B_Report.html').write_text(report,encoding='utf-8')
