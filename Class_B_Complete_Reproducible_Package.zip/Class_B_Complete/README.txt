CLASS B — COMPLETE REPRODUCIBLE ANALYSIS PACKAGE

Open Class_B_Report_With_Graphs_No_Date.html to view the report.
Both charts are embedded in the report; separate PNG copies are in results/.
All result tables are included as CSV files in results/.

REPRODUCING THE ANALYSIS
Requires Python 3 with numpy, pandas, scipy and matplotlib.
Keep the three Python scripts together in code/.
From the package root, run:

python code/analyze_platform_age.py /absolute/path/to/Class_B_X_YouTube_Final(1).csv --output rerun_results

If the input path contains spaces or parentheses, quote the whole path.
The original source CSV is not included; use the CSV you supplied.
Platform is primary; age is examined within platforms. Gender/sex is excluded
from models and sample selection. The source column is dropped during loading.
No analysis date is added. The rerun includes both graphs.

The verification disclaimer is included in the report and results/.
Not all rows or associated metadata could be independently verified.
Language metadata is available only on X records.
